package com.scriptengine.editor

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.scriptengine.R
import com.scriptengine.engine.ScreenCapture
import java.io.File

class CodeEditorActivity : AppCompatActivity() {

    companion object {
        private const val RC_MEDIA_PROJECTION = 2001
        private const val PREFS_NAME = "editor_prefs"
        private const val PREF_CURRENT_FILE = "current_file"
    }

    private lateinit var editText: EditText
    private lateinit var tvCursorPos: TextView
    private lateinit var tvColorPreview: TextView
    private lateinit var btnPickColor: Button
    private lateinit var progressBar: ProgressBar

    private var currentFile: File? = null
    private var screenCapture: ScreenCapture? = null
    private var mediaProjection: MediaProjection? = null
    private var isColorPickerMode = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var colorPickRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_code_editor)

        setupUI()
        loadFile()
        setupSyntaxHighlighting()
    }

    private fun setupUI() {
        editText = findViewById(R.id.etCode)
        tvCursorPos = findViewById(R.id.tvCursorPos)
        tvColorPreview = findViewById(R.id.tvColorPreview)
        btnPickColor = findViewById(R.id.btnPickColor)
        progressBar = findViewById(R.id.progressBar)

        findViewById<Button>(R.id.btnSave).setOnClickListener { saveFile() }
        findViewById<Button>(R.id.btnRun).setOnClickListener { runScript() }
        findViewById<Button>(R.id.btnOpen).setOnClickListener { openFile() }
        findViewById<Button>(R.id.btnNew).setOnClickListener { newFile() }

        btnPickColor.setOnClickListener {
            if (!isColorPickerMode) {
                startColorPicker()
            } else {
                stopColorPicker()
            }
        }

        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateCursorPosition()
            }
        })

        editText.setOnKeyListener { _, _, _ ->
            updateCursorPosition()
            false
        }
    }

    private fun setupSyntaxHighlighting() {
        // Простая подсветка для демо - можно заменить на SyntaxHighlighter библиотеку
        // Для производительности используем регулярки
        editText.addTextChangedListener(object : TextWatcher {
            private var isUpdating = false

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (isUpdating) return
                isUpdating = true
                highlightSyntax(s.toString())
                isUpdating = false
            }
        })
    }

    private fun highlightSyntax(text: String) {
        // Это упрощенная версия - для продакшена используйте библиотеку
        // HighlightingEditor или CodeView
        try {
            val spannable = editText.text
            // Очищаем предыдущие стили
            val spans = spannable.getSpans(0, spannable.length, android.text.style.ForegroundColorSpan::class.java)
            spans.forEach { spannable.removeSpan(it) }

            // Ключевые слова Python
            val keywords = setOf("def", "class", "import", "from", "as", "if", "else", "elif",
                "for", "while", "break", "continue", "return", "True", "False", "None", "and", "or", "not")

            val words = text.split(Regex("\\W+"))
            var index = 0
            for (word in words) {
                val startIdx = text.indexOf(word, index)
                if (startIdx >= 0 && keywords.contains(word)) {
                    spannable.setSpan(
                        android.text.style.ForegroundColorSpan(Color.parseColor("#FF6B6B")),
                        startIdx, startIdx + word.length,
                        android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
                index = startIdx + word.length
            }
        } catch (e: Exception) {
            // Игнорируем ошибки подсветки
        }
    }

    private fun updateCursorPosition() {
        val selectionStart = editText.selectionStart
        if (selectionStart >= 0) {
            val text = editText.text.toString()
            val lines = text.substring(0, selectionStart).split("\n")
            val line = lines.size
            val column = lines.last().length + 1
            tvCursorPos.text = "Line $line, Col $column"
        }
    }

    private fun loadFile() {
        val path = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(PREF_CURRENT_FILE, null)

        if (path != null) {
            currentFile = File(path)
            if (currentFile?.exists() == true) {
                editText.setText(currentFile?.readText())
                title = currentFile?.name
            }
        }
    }

    private fun saveFile() {
        if (currentFile == null) {
            showSaveDialog()
        } else {
            currentFile?.writeText(editText.text.toString())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            title = currentFile?.name
        }
    }

    private fun showSaveDialog() {
        val input = EditText(this)
        input.hint = "script_name.py"

        AlertDialog.Builder(this)
            .setTitle("Save Script")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString()
                if (name.isNotEmpty()) {
                    val scriptsDir = File(getExternalFilesDir(null), "scripts")
                    scriptsDir.mkdirs()
                    currentFile = File(scriptsDir, name)
                    saveFile()

                    getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit()
                        .putString(PREF_CURRENT_FILE, currentFile?.absolutePath)
                        .apply()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openFile() {
        val scriptsDir = File(getExternalFilesDir(null), "scripts")
        val scripts = scriptsDir.listFiles { f -> f.extension == "py" } ?: emptyArray()

        if (scripts.isEmpty()) {
            Toast.makeText(this, "No scripts found", Toast.LENGTH_SHORT).show()
            return
        }

        val names = scripts.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Open Script")
            .setItems(names) { _, which ->
                currentFile = scripts[which]
                editText.setText(currentFile?.readText())
                title = currentFile?.name

                getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(PREF_CURRENT_FILE, currentFile?.absolutePath)
                    .apply()
            }
            .show()
    }

    private fun newFile() {
        currentFile = null
        editText.setText("")
        title = "New Script"
    }

    private fun runScript() {
        saveFile()
        val intent = Intent(this, com.scriptengine.MainActivity::class.java).apply {
            putExtra("run_script", currentFile?.absolutePath)
        }
        startActivity(intent)
        finish()
    }

    // ──────────────────────── Color Picker ────────────────────────

    private fun startColorPicker() {
        if (mediaProjection == null) {
            requestMediaProjection()
        } else {
            enableColorPickerMode()
        }
    }

    private fun requestMediaProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), RC_MEDIA_PROJECTION)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK && data != null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mpm.getMediaProjection(resultCode, data)

            val metrics = resources.displayMetrics
            screenCapture = ScreenCapture(this).apply {
                initialize(mediaProjection!!, metrics.widthPixels, metrics.heightPixels, metrics.densityDpi)
            }
            enableColorPickerMode()
        }
    }

    private fun enableColorPickerMode() {
        isColorPickerMode = true
        btnPickColor.text = "🔴 Stop Picker"
        btnPickColor.setBackgroundColor(Color.parseColor("#FF6B6B"))

        // Создаем overlay для отображения пипетки
        showColorPickerOverlay()
    }

    private fun showColorPickerOverlay() {
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        val overlayView = ColorPickerOverlayView(this) { x, y, color ->
            runOnUiThread {
                val hex = String.format("#%08X", color)
                tvColorPreview.text = "Color: $hex at ($x, $y)"
                tvColorPreview.setBackgroundColor(color)

                // Вставляем координаты и цвет в редактор
                val code = editText.text.toString()
                val cursorPos = editText.selectionStart
                val newText = code.substring(0, cursorPos) +
                        getColorCode(x, y, color) +
                        code.substring(cursorPos)
                editText.setText(newText)
                editText.setSelection(cursorPos + getColorCode(x, y, color).length)
            }
        }

        windowManager.addView(overlayView, params)

        // Автоматически скрываем через 30 секунд
        mainHandler.postDelayed({
            if (isColorPickerMode) {
                stopColorPicker()
                windowManager.removeView(overlayView)
            }
        }, 30000)
    }

    private fun getColorCode(x: Int, y: Int, color: Int): String {
        val hex = String.format("%08X", color)
        return "\n# Color picker: ($x, $y) = $hex\n# get_color($x, $y)\n"
    }

    private fun stopColorPicker() {
        isColorPickerMode = false
        btnPickColor.text = "🎨 Pick Color"
        btnPickColor.setBackgroundColor(ContextCompat.getColor(this, android.R.color.transparent))
        screenCapture?.release()
        mediaProjection?.stop()
        mediaProjection = null
    }

    // Внутренний класс для overlay
    inner class ColorPickerOverlayView(
        context: Context,
        private val onColorPicked: (x: Int, y: Int, color: Int) -> Unit
    ) : View(context) {

        private var lastX = 0
        private var lastY = 0
        private val paint = Paint().apply {
            color = Color.WHITE
            textSize = 24f
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    lastX = event.rawX.toInt()
                    lastY = event.rawY.toInt()
                    invalidate()

                    // Получаем цвет под пальцем
                    val color = screenCapture?.getColor(lastX, lastY) ?: -1
                    onColorPicked(lastX, lastY, color)
                }
                MotionEvent.ACTION_UP -> {
                    // Фиксируем выбор
                    val color = screenCapture?.getColor(lastX, lastY) ?: -1
                    onColorPicked(lastX, lastY, color)
                    stopColorPicker()
                    (parent as? ViewGroup)?.removeView(this)
                }
            }
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            // Рисуем лупу
            canvas.drawCircle(lastX.toFloat(), lastY.toFloat(), 60f, Paint().apply {
                color = Color.BLACK
                alpha = 128
                style = Paint.Style.FILL
            })
            canvas.drawCircle(lastX.toFloat(), lastY.toFloat(), 60f, Paint().apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = 2f
            })

            // Текст с координатами
            val text = "$lastX, $lastY"
            canvas.drawText(text, lastX - 30f, lastY - 70f, paint)
        }
    }
}