package com.scriptengine.engine

import android.graphics.Bitmap
import android.util.Log
import java.lang.ref.SoftReference

class ImageFinder {

    companion object {
        private const val TAG = "ImageFinder"
        private const val DEFAULT_THRESHOLD = 0.85f

        // Reuse nativeAvailable from ScreenCapture — same library
        val nativeAvailable: Boolean get() = ScreenCapture.nativeAvailable
    }

    private external fun nativeFindImage(
        screenBitmap: Bitmap, templateBitmap: Bitmap,
        x1: Int, y1: Int, x2: Int, y2: Int, threshold: Float
    ): FloatArray?

    private external fun nativeFindImageAll(
        screenBitmap: Bitmap, templateBitmap: Bitmap,
        x1: Int, y1: Int, x2: Int, y2: Int, threshold: Float
    ): FloatArray?

    private val templateCache = HashMap<String, SoftReference<Bitmap>>()

    data class Point(val x: Int, val y: Int, val confidence: Float)

    fun findImage(
        screenBitmap: Bitmap, template: Bitmap,
        x1: Int, y1: Int, x2: Int, y2: Int,
        threshold: Float = DEFAULT_THRESHOLD
    ): Point? {
        if (!nativeAvailable) return null
        val raw = nativeFindImage(screenBitmap, template, x1, y1, x2, y2, threshold) ?: return null
        return Point(raw[0].toInt(), raw[1].toInt(), raw[2])
    }

    fun hasImage(
        screenBitmap: Bitmap, template: Bitmap,
        x1: Int = 0, y1: Int = 0, x2: Int = Int.MAX_VALUE, y2: Int = Int.MAX_VALUE,
        threshold: Float = DEFAULT_THRESHOLD
    ): Boolean {
        if (!nativeAvailable) return false
        val safeX2 = if (x2 == Int.MAX_VALUE) screenBitmap.width else x2
        val safeY2 = if (y2 == Int.MAX_VALUE) screenBitmap.height else y2
        return nativeFindImage(screenBitmap, template, x1, y1, safeX2, safeY2, threshold) != null
    }

    fun findImageAll(
        screenBitmap: Bitmap, template: Bitmap,
        x1: Int, y1: Int, x2: Int, y2: Int,
        threshold: Float = DEFAULT_THRESHOLD
    ): List<Point> {
        if (!nativeAvailable) return emptyList()
        val raw = nativeFindImageAll(screenBitmap, template, x1, y1, x2, y2, threshold) ?: return emptyList()
        val result = mutableListOf<Point>()
        var i = 0
        while (i + 2 < raw.size) { result.add(Point(raw[i].toInt(), raw[i+1].toInt(), raw[i+2])); i += 3 }
        return result
    }

    fun cacheTemplate(key: String, bitmap: Bitmap) { templateCache[key] = SoftReference(bitmap) }
    fun getCachedTemplate(key: String): Bitmap? = templateCache[key]?.get()
    fun clearCache() { templateCache.clear() }
}
