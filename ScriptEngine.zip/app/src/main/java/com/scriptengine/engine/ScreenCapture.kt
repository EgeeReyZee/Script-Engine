package com.scriptengine.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.util.Log
import java.util.concurrent.locks.ReentrantReadWriteLock

class ScreenCapture(private val context: Context) {

    companion object {
        private const val TAG = "ScreenCapture"
        private const val CACHE_TTL_MS = 50L

        // Whether native JNI library loaded successfully
        var nativeAvailable = false
            private set

        init {
            nativeAvailable = tryLoadNative()
        }

        private fun tryLoadNative(): Boolean {
            // Step 1: try to load opencv_java4 (our libscriptengine.so links against it)
            var opencvLoaded = false
            try {
                System.loadLibrary("opencv_java4")
                opencvLoaded = true
                Log.i(TAG, "opencv_java4 loaded OK")
            } catch (e: UnsatisfiedLinkError) {
                Log.w(TAG, "opencv_java4 not available for this ABI: ${e.message}")
            }

            // Step 2: load our library
            return try {
                System.loadLibrary("scriptengine")
                Log.i(TAG, "scriptengine loaded OK (opencv=$opencvLoaded)")
                true
            } catch (e: UnsatisfiedLinkError) {
                Log.e(TAG, "scriptengine load FAILED: ${e.message}")
                Log.e(TAG, "ABI: ${System.getProperty("os.arch")} — native features disabled")
                false
            }
        }
    }

    // JNI — only called when nativeAvailable == true
    private external fun nativeGetColor(bitmap: Bitmap, x: Int, y: Int): Int
    private external fun nativeGetColors(bitmap: Bitmap, xArray: IntArray, yArray: IntArray): IntArray

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDpi = 0

    private var reusableBitmap: Bitmap? = null
    private val lock = ReentrantReadWriteLock()
    private var lastCaptureTime = 0L

    private val captureThread = HandlerThread("ScreenCaptureThread",
        Process.THREAD_PRIORITY_BACKGROUND).also { it.start() }
    private val captureHandler = Handler(captureThread.looper)

    fun initialize(projection: MediaProjection, width: Int, height: Int, dpi: Int) {
        this.mediaProjection = projection
        this.screenWidth = width
        this.screenHeight = height
        this.screenDpi = dpi

        reusableBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        virtualDisplay = projection.createVirtualDisplay(
            "ScriptEngineCapture", width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, captureHandler
        )
        Log.i(TAG, "Initialized ${width}x${height}")
    }

    private fun captureFrame() {
        val now = System.currentTimeMillis()
        if (now - lastCaptureTime < CACHE_TTL_MS) return
        val reader = imageReader ?: return
        val bitmap = reusableBitmap ?: return

        lock.writeLock().lock()
        try {
            val image = reader.acquireLatestImage() ?: return
            try {
                val planes = image.planes
                val buffer = planes[0].buffer
                val pixelStride = planes[0].pixelStride
                val rowStride = planes[0].rowStride
                val rowPadding = rowStride - pixelStride * screenWidth
                if (rowPadding == 0) {
                    bitmap.copyPixelsFromBuffer(buffer)
                } else {
                    val tmp = Bitmap.createBitmap(rowStride / pixelStride, screenHeight, Bitmap.Config.ARGB_8888)
                    tmp.copyPixelsFromBuffer(buffer)
                    val canvas = android.graphics.Canvas(bitmap)
                    canvas.drawBitmap(tmp,
                        android.graphics.Rect(0, 0, screenWidth, screenHeight),
                        android.graphics.Rect(0, 0, screenWidth, screenHeight), null)
                    tmp.recycle()
                }
                lastCaptureTime = System.currentTimeMillis()
            } finally {
                image.close()
            }
        } catch (e: Exception) {
            Log.e(TAG, "captureFrame error", e)
        } finally {
            lock.writeLock().unlock()
        }
    }

    fun getColor(x: Int, y: Int): Int {
        if (!nativeAvailable) return getColorFallback(x, y)
        captureFrame()
        lock.readLock().lock()
        return try {
            nativeGetColor(reusableBitmap ?: return -1, x, y)
        } finally {
            lock.readLock().unlock()
        }
    }

    // Pure-Kotlin fallback for devices where native lib unavailable
    private fun getColorFallback(x: Int, y: Int): Int {
        captureFrame()
        lock.readLock().lock()
        return try {
            reusableBitmap?.getPixel(x, y) ?: -1
        } catch (e: Exception) { -1 }
        finally { lock.readLock().unlock() }
    }

    fun getColors(points: List<Pair<Int, Int>>): IntArray {
        if (!nativeAvailable) return IntArray(points.size) { getColorFallback(points[it].first, points[it].second) }
        captureFrame()
        lock.readLock().lock()
        return try {
            val bitmap = reusableBitmap ?: return IntArray(points.size) { -1 }
            val xs = IntArray(points.size) { points[it].first }
            val ys = IntArray(points.size) { points[it].second }
            nativeGetColors(bitmap, xs, ys)
        } finally {
            lock.readLock().unlock()
        }
    }

    fun getScreenBitmap(): Bitmap? {
        captureFrame()
        lock.readLock().lock()
        return try {
            reusableBitmap?.copy(reusableBitmap!!.config, false)
        } finally {
            lock.readLock().unlock()
        }
    }

    fun getScreenSize(): Pair<Int, Int> = Pair(screenWidth, screenHeight)

    fun release() {
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.close(); imageReader = null
        mediaProjection?.stop(); mediaProjection = null
        reusableBitmap?.recycle(); reusableBitmap = null
        captureThread.quitSafely()
    }
}
